IDRegistry.genItemID("item_axe_crystal_black");
IDRegistry.genItemID("item_axe_crystal_blue");
IDRegistry.genItemID("item_axe_crystal_green");
IDRegistry.genItemID("item_axe_crystal_light_blue");
IDRegistry.genItemID("item_axe_crystal_red");
IDRegistry.genItemID("item_axe_crystal_white");
IDRegistry.genItemID("item_axe_emerald");
IDRegistry.genItemID("item_axe_light");
IDRegistry.genItemID("item_axe_obsidian");
IDRegistry.genItemID("item_axe_quartz");

IDRegistry.genItemID("item_bag");

IDRegistry.genItemID("item_battery_double");
IDRegistry.genItemID("item_battery_quadruple");
IDRegistry.genItemID("item_battery_quintuple");
IDRegistry.genItemID("item_battery_triple");
IDRegistry.genItemID("item_battery");

IDRegistry.genItemID("item_booklet");

IDRegistry.genItemID("item_bucket_canola_oil");
IDRegistry.genItemID("item_bucket_oil");

IDRegistry.genItemID("item_chest_to_crate_upgrade");

IDRegistry.genItemID("item_coffee_beans");
IDRegistry.genItemID("item_coffee_seed");
IDRegistry.genItemID("item_coffee");

IDRegistry.genItemID("item_color_lens");
IDRegistry.genItemID("item_crafter_on_a_stick");
IDRegistry.genItemID("item_crate_keeper");
IDRegistry.genItemID("item_crate_to_crafty_upgrade");

IDRegistry.genItemID("item_chest_crystal_black");
IDRegistry.genItemID("item_chest_crystal_blue");
IDRegistry.genItemID("item_chest_crystal_empowered_black");
IDRegistry.genItemID("item_chest_crystal_empowered_blue");
IDRegistry.genItemID("item_chest_crystal_empowered_green");
IDRegistry.genItemID("item_chest_crystal_empowered_light_blue");
IDRegistry.genItemID("item_chest_crystal_empowered_red");
IDRegistry.genItemID("item_chest_crystal_empowered_white");
IDRegistry.genItemID("item_crystal_green");
IDRegistry.genItemID("item_crystal_light_blue");
IDRegistry.genItemID("item_crystal_red");
IDRegistry.genItemID("item_crystal_shard");
IDRegistry.genItemID("item_crystal_white");

IDRegistry.genItemID("item_damage_lens");
IDRegistry.genItemID("item_disenchanting_lens");


IDRegistry.genItemID("item_drill_black");
IDRegistry.genItemID("item_drill_blue");
IDRegistry.genItemID("item_drill_brown");
IDRegistry.genItemID("item_drill_cyan");
IDRegistry.genItemID("item_drill_gray");
IDRegistry.genItemID("item_drill_green");
IDRegistry.genItemID("item_drill_light_blue");
IDRegistry.genItemID("item_drill_light_gray");
IDRegistry.genItemID("item_drill_lime");
IDRegistry.genItemID("item_drill_magenta");
IDRegistry.genItemID("item_drill_orange");
IDRegistry.genItemID("item_drill_pink");
IDRegistry.genItemID("item_drill_purple");
IDRegistry.genItemID("item_drill_red");

IDRegistry.genItemID("item_drill_upgrade_block_placing");
IDRegistry.genItemID("item_drill_upgrade_five_by_five");
IDRegistry.genItemID("item_drill_upgrade_fortune");
IDRegistry.genItemID("item_drill_upgrade_silk_touch");
IDRegistry.genItemID("item_drill_upgrade_speed_ii");
IDRegistry.genItemID("item_drill_upgrade_speed_iii");
IDRegistry.genItemID("item_drill_upgrade_speed");
IDRegistry.genItemID("item_drill_upgrade_three_by_three");
IDRegistry.genItemID("item_drill_upgrade");

IDRegistry.genItemID("item_drill_white");
IDRegistry.genItemID("item_drill_yellow");

IDRegistry.genItemID("item_dust");
IDRegistry.genItemID("item_engineer_goggles_advanced");
IDRegistry.genItemID("item_engineer_goggles");
IDRegistry.genItemID("item_explosion_lens");
IDRegistry.genItemID("item_fertilizer");
IDRegistry.genItemID("item_filling_wand");
IDRegistry.genItemID("item_filter");
IDRegistry.genItemID("item_flax_seed");

IDRegistry.genItemID("item_food_bacon");
IDRegistry.genItemID("item_food_baguette");
IDRegistry.genItemID("item_food_big_cookie");
IDRegistry.genItemID("item_food_cheese");
IDRegistry.genItemID("item_food_chocolate_cake");
IDRegistry.genItemID("item_food_chocolate_toast");
IDRegistry.genItemID("item_food_chocolate");
IDRegistry.genItemID("item_food_doughnut");
IDRegistry.genItemID("item_food_fish_n_chips");
IDRegistry.genItemID("item_food_french_fries");
IDRegistry.genItemID("item_food_french_fry");
IDRegistry.genItemID("item_food_hamburger");
IDRegistry.genItemID("item_food_noodle");
IDRegistry.genItemID("item_food_pizza");
IDRegistry.genItemID("item_food_pumpkin_stew");
IDRegistry.genItemID("item_food_rice_bread");
IDRegistry.genItemID("item_food_rice");
IDRegistry.genItemID("item_food_spaghetti");
IDRegistry.genItemID("item_food_submarine_sandwich");
IDRegistry.genItemID("item_food_toast");

IDRegistry.genItemID("item_growth_ring");
IDRegistry.genItemID("item_hairy_ball");

IDRegistry.genItemID("item_hoe_crystal_black");
IDRegistry.genItemID("item_hoe_crystal_blue");
IDRegistry.genItemID("item_hoe_crystal_green");
IDRegistry.genItemID("item_hoe_crystal_light_blue");
IDRegistry.genItemID("item_hoe_crystal_red");
IDRegistry.genItemID("item_hoe_crystal_white");
IDRegistry.genItemID("item_hoe_emerald");
IDRegistry.genItemID("item_hoe_crystal_light");
IDRegistry.genItemID("item_hoe_obsidian");
IDRegistry.genItemID("item_hoe_quartz");

IDRegistry.genItemID("item_jam_overlay");
IDRegistry.genItemID("item_jam");
IDRegistry.genItemID("item_juicer");
IDRegistry.genItemID("item_knife");
IDRegistry.genItemID("item_laser_upgrade_invisibility");
IDRegistry.genItemID("item_laser_upgrade_range");
IDRegistry.genItemID("item_laser_wrench");
IDRegistry.genItemID("item_leaf_blower_advanced");
IDRegistry.genItemID("item_leaf_blower_advanced");
IDRegistry.genItemID("item_light_wand");
IDRegistry.genItemID("item_manual");
IDRegistry.genItemID("item_medium_to_large_crate_upgrade");
IDRegistry.genItemID("item_minecart_firework_box");
IDRegistry.genItemID("item_mining_lens");

IDRegistry.genItemID("item_misc_bat_wing");
IDRegistry.genItemID("item_misc_biocoal");
IDRegistry.genItemID("item_misc_biomass");
IDRegistry.genItemID("item_misc_black_dye");
IDRegistry.genItemID("item_misc_black_quartz");
IDRegistry.genItemID("item_misc_canola");
IDRegistry.genItemID("item_misc_coil_advanced");
IDRegistry.genItemID("item_misc_coil");
IDRegistry.genItemID("item_misc_crystallized_canola_seed");
IDRegistry.genItemID("item_misc_cup");
IDRegistry.genItemID("item_misc_dough");
IDRegistry.genItemID("item_misc_drill_core");
IDRegistry.genItemID("item_misc_empowered_canola_seed");
IDRegistry.genItemID("item_misc_ender_star");
IDRegistry.genItemID("item_misc_knife_blade");
IDRegistry.genItemID("item_misc_knife_handle");
IDRegistry.genItemID("item_misc_lens");
IDRegistry.genItemID("item_misc_mashed_food");
IDRegistry.genItemID("item_misc_paper_cone");
IDRegistry.genItemID("item_misc_rice_dough");
IDRegistry.genItemID("item_misc_rice_slime");
IDRegistry.genItemID("item_misc_ring");
IDRegistry.genItemID("item_misc_spawner_shard");
IDRegistry.genItemID("item_misc_tiny_charcoal");
IDRegistry.genItemID("item_misc_tiny_coal");
IDRegistry.genItemID("item_misc_youtube_icon");
IDRegistry.genItemID("item_more_damage_lens");

IDRegistry.genItemID("item_paxel_overlay");
IDRegistry.genItemID("item_paxel");
IDRegistry.genItemID("item_phantom_connector");

IDRegistry.genItemID("item_pickaxe_crystal_black");
IDRegistry.genItemID("item_pickaxe_crystal_blue");
IDRegistry.genItemID("item_pickaxe_crystal_green");
IDRegistry.genItemID("item_pickaxe_crystal_light_blue");
IDRegistry.genItemID("item_pickaxe_crystal_red");
IDRegistry.genItemID("item_pickaxe_crystal_white");
IDRegistry.genItemID("item_pickaxe_emerald");
IDRegistry.genItemID("item_pickaxe_light");
IDRegistry.genItemID("item_pickaxe_obsidian");
IDRegistry.genItemID("item_pickaxe_quartz");

IDRegistry.genItemID("item_player_probe");
IDRegistry.genItemID("item_potion_ring_advanced");
IDRegistry.genItemID("item_potion_ring");
IDRegistry.genItemID("item_rarmor_module_reconstructor");
IDRegistry.genItemID("item_resonant_rice");
IDRegistry.genItemID("item_rice_seed");
IDRegistry.genItemID("item_shears_light");

IDRegistry.genItemID("item_shovel_crystal_black");
IDRegistry.genItemID("item_shovel_crystal_blue");
IDRegistry.genItemID("item_shovel_crystal_green");
IDRegistry.genItemID("item_shovel_crystal_light_blue");
IDRegistry.genItemID("item_shovel_crystal_red");
IDRegistry.genItemID("item_shovel_crystal_white");
IDRegistry.genItemID("item_shovel_emerald");
IDRegistry.genItemID("item_shovel_light");
IDRegistry.genItemID("item_shovel_obsidian");
IDRegistry.genItemID("item_shovel_quartz");

IDRegistry.genItemID("item_small_to_medium_crate_upgrade");
IDRegistry.genItemID("item_snail");
IDRegistry.genItemID("item_solidified_experience");
IDRegistry.genItemID("item_spawner_changer");
IDRegistry.genItemID("item_suction_ring");

IDRegistry.genItemID("item_sword_crystal_black");
IDRegistry.genItemID("item_sword_crystal_blue");
IDRegistry.genItemID("item_sword_crystal_green");
IDRegistry.genItemID("item_sword_crystal_light_blue");
IDRegistry.genItemID("item_sword_crystal_red");
IDRegistry.genItemID("item_sword_crystal_white");
IDRegistry.genItemID("item_sword_emerald");
IDRegistry.genItemID("item_sword_light");
IDRegistry.genItemID("item_sword_obsidian");
IDRegistry.genItemID("item_sword_quartz");


IDRegistry.genItemID("item_tablet");
IDRegistry.genItemID("item_tele_staff");
IDRegistry.genItemID("item_upgrade_speed");
IDRegistry.genItemID("item_void_bag");
IDRegistry.genItemID("item_water_bowl");
IDRegistry.genItemID("item_water_removal_ring");
IDRegistry.genItemID("item_wings_of_the_bats");
IDRegistry.genItemID("item_worm");
