var gui_bg = {type: "background", color: android.graphics.Color.rgb(179, 179, 179)};
var gui = {
	x: 470, 
	y: 130,
		s: 3.2, 
		m: 3.3,
		b: 3.4,
};