IDRegistry.genBlockID("block_atomic_reconstructor");
IDRegistry.genBlockID("block_bio_reactor");
IDRegistry.genBlockID("block_breaker");
IDRegistry.genBlockID("block_canola_press");
IDRegistry.genBlockID("block_coal_generator");
IDRegistry.genBlockID("block_crystal_black");
IDRegistry.genBlockID("block_crystal_blue");
IDRegistry.genBlockID("block_crystal_cluster");
IDRegistry.genBlockID("block_crystal_green");

IDRegistry.genBlockID("block_crystal_light_blue");
IDRegistry.genBlockID("block_crystal_red");
IDRegistry.genBlockID("block_crystal_white");
IDRegistry.genBlockID("block_directional_breaker");
IDRegistry.genBlockID("block_display_stand");
IDRegistry.genBlockID("block_dropper");
IDRegistry.genBlockID("block_energizer");
IDRegistry.genBlockID("block_enervator");

IDRegistry.genBlockID("block_farmer");
IDRegistry.genBlockID("block_feeder");
IDRegistry.genBlockID("block_fermenting_barrel");
IDRegistry.genBlockID("block_fluid_collector");
IDRegistry.genBlockID("block_fluid_placer");
IDRegistry.genBlockID("block_furnace_double");

IDRegistry.genBlockID("block_giant_chest_large");
IDRegistry.genBlockID("block_giant_chest_medium");
IDRegistry.genBlockID("block_giant_chest");

IDRegistry.genBlockID("block_greenhouse_glass");
IDRegistry.genBlockID("block_grinder_double");
IDRegistry.genBlockID("block_grinder");
IDRegistry.genBlockID("block_heat_collector");
IDRegistry.genBlockID("block_inputter_advanced");
IDRegistry.genBlockID("block_inputter");
IDRegistry.genBlockID("block_item_distributor");
IDRegistry.genBlockID("block_item_repairer");

IDRegistry.genBlockID("block_item_viewer");
IDRegistry.genBlockID("block_lamp_powerer");
IDRegistry.genBlockID("block_lava_factory_controller");
IDRegistry.genBlockID("block_leaf_generator");
IDRegistry.genBlockID("block_miner");
IDRegistry.genBlockID("block_misc_black_quartz_chiseled");
IDRegistry.genBlockID("block_misc_black_quartz_pillar");
IDRegistry.genBlockID("block_misc_black_quartz");

IDRegistry.genBlockID("block_misc_charcoal");
IDRegistry.genBlockID("block_misc_ender_casing");
IDRegistry.genBlockID("block_misc_enderpearl");
IDRegistry.genBlockID("block_misc_iron_casing_snow");
IDRegistry.genBlockID("block_misc_iron_casing");
IDRegistry.genBlockID("block_misc_lava_factory_case");
IDRegistry.genBlockID("block_misc_wood_casing");
IDRegistry.genBlockID("block_oil_generator");

IDRegistry.genBlockID("block_phantom_breaker");
IDRegistry.genBlockID("block_phantom_energyface");
IDRegistry.genBlockID("block_phantom_liquiface");
IDRegistry.genBlockID("block_phantom_placer");
IDRegistry.genBlockID("block_phantom_redstoneface");
IDRegistry.genBlockID("block_phantomface_pumpkin");
IDRegistry.genBlockID("block_phantomface");
IDRegistry.genBlockID("block_placer");

IDRegistry.genBlockID("block_player_interface");
IDRegistry.genBlockID("block_ranged_collector");
IDRegistry.genBlockID("block_shock_absorber");
IDRegistry.genBlockID("block_treasure_chest");
IDRegistry.genBlockID("block_tiny_torch");
IDRegistry.genBlockID("block_xp_solidifier");
