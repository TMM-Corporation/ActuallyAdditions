LiquidRegistry.registerLiquid("canola_oil", "Canola Oil", ["canola_s"]);
LiquidRegistry.registerItem("canola_oil", {id: 325, data: 0}, {id: ItemID.item_bucket_canola_oil, data: 0});

LiquidRegistry.registerLiquid("refined_canola_oil", "Regined Canola Oil", ["canola_refined_s"]);
LiquidRegistry.registerItem("refined_canola_oil", {id: 325, data: 0}, {id: ItemID.item_bucket_oil, data: 0});