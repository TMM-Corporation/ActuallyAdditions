IDRegistry.genItemID("item_helm_crystal_black");
IDRegistry.genItemID("item_helm_crystal_blue");
IDRegistry.genItemID("item_helm_crystal_green");
IDRegistry.genItemID("item_helm_crystal_light_blue");
IDRegistry.genItemID("item_helm_crystal_red");
IDRegistry.genItemID("item_helm_crystal_white");
IDRegistry.genItemID("item_helm_emerald");
IDRegistry.genItemID("item_helm_light");
IDRegistry.genItemID("item_helm_obsidian");
IDRegistry.genItemID("item_helm_quartz");

IDRegistry.genItemID("item_chest_crystal_black");
IDRegistry.genItemID("item_chest_crystal_blue");
IDRegistry.genItemID("item_chest_crystal_green");
IDRegistry.genItemID("item_chest_crystal_light_blue");
IDRegistry.genItemID("item_chest_crystal_red");
IDRegistry.genItemID("item_chest_crystal_white");
IDRegistry.genItemID("item_chest_emerald");
IDRegistry.genItemID("item_chest_light");
IDRegistry.genItemID("item_chest_obsidian");
IDRegistry.genItemID("item_chest_quartz");

IDRegistry.genItemID("item_pants_crystal_black");
IDRegistry.genItemID("item_pants_crystal_blue");
IDRegistry.genItemID("item_pants_crystal_green");
IDRegistry.genItemID("item_pants_crystal_light_blue");
IDRegistry.genItemID("item_pants_crystal_red");
IDRegistry.genItemID("item_pants_crystal_white");
IDRegistry.genItemID("item_pants_emerald");
IDRegistry.genItemID("item_pants_light");
IDRegistry.genItemID("item_pants_obsidian");
IDRegistry.genItemID("item_pants_quartz");

IDRegistry.genItemID("item_boots_crystal_black");
IDRegistry.genItemID("item_boots_crystal_blue");
IDRegistry.genItemID("item_boots_crystal_green");
IDRegistry.genItemID("item_boots_crystal_light_blue");
IDRegistry.genItemID("item_boots_crystal_red");
IDRegistry.genItemID("item_boots_crystal_white");
IDRegistry.genItemID("item_boots_emerald");
IDRegistry.genItemID("item_boots_light");
IDRegistry.genItemID("item_boots_obsidian");
IDRegistry.genItemID("item_boots_quartz");

