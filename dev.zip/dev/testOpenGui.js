var testOpen = new UI.Container();
Callback.addCallback("PostLoaded", function () {
    testOpen.openAs(generatorUI);
});